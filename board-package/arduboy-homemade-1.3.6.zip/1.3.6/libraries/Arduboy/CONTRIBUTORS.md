# Individual Contributors

- Kevin "Arduboy" Bates (@Arduboy)
- arduboychris (@arduboychris)
- Josh Goebel (@yyyc514)
- Scott Allen (@MLXXXp)
- Ross Shoger (@rogosher)
- Andrew (@ace-dent)


# Included code from other open source projects

- Original SSD1306 library
  https://github.com/adafruit/Adafruit_SSD1306
  BSD License
  Copyright (c) 2012, Adafruit Industries

- arduino-playtune
  https://github.com/LenShustek/arduino-playtune
  GNU General Public License v3
  (C) Copyright 2011, 2015, Len Shustek
