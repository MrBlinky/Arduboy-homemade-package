# ArduboyFX
Library for accessing the external flash memory of the Arduboy FX and home made Arduboys with a flash chip.
