### NOTES IN CHORDS

| chord | Major   	| next nrs | ATM parameter | Minor   	| next nrs  | ATM parameter |
| ---   | ---     	| ---      | ---           | ---     	| ---       | ---           |
| C     | C,E,G     |  + 4 + 3 |   0x43 or 67  | C,D#,G     |  + 3 + 4  |   0x34 or 52  |
| C#    | C#,F,G#   |  + 4 + 3 |   0x43 or 67  | C#,E,G#    |  + 3 + 4  |   0x34 or 52  |
| D     | D,F#,A    |  + 4 + 3 |   0x43 or 67  | D,F,A      |  + 3 + 4  |   0x34 or 52  |
| D#    | D#,G,A#   |  + 4 + 3 |   0x43 or 67  | D#,F#,A#   |  + 3 + 4  |   0x34 or 52  |
| E     | E,G#,B    |  + 4 + 3 |   0x43 or 67  | E,G,B      |  + 3 + 4  |   0x34 or 52  |
| F     | F,A,C     |  + 4 + 3 |   0x43 or 67  | F,G#,C     |  + 3 + 4  |   0x34 or 52  |
| F#    | F#,A#,C#  |  + 4 + 3 |   0x43 or 67  | F#,A,C#    |  + 3 + 4  |   0x34 or 52  |
| G     | G,B,D     |  + 4 + 3 |   0x43 or 67  | G,A#,D     |  + 3 + 4  |   0x34 or 52  |
| G#    | G#,C,D#   |  + 4 + 3 |   0x43 or 67  | G#,B,D#    |  + 3 + 4  |   0x34 or 52  |
| A     | A,C#,E    |  + 4 + 3 |   0x43 or 67  | A,C,E      |  + 3 + 4  |   0x34 or 52  |
| A#    | A#,D,F    |  + 4 + 3 |   0x43 or 67  | A#,C#,F    |  + 3 + 4  |   0x34 or 52  |
| B     | B,D#,F#   |  + 4 + 3 |   0x43 or 67  | B,D,F#     |  + 3 + 4  |   0x34 or 52  |


Major chord - made up of the 1,3, and 5 note in that keys scale.  Minor chord - flat the 3rd note of the scale